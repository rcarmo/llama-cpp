# Configuration inheritance and opportunity register

## Retained configuration

| Factor | State | Evidence / boundary |
|---|---|---|
| ThinkingCap MXFP4_MOE file/revision | Preserved | ThinkingCap file/SHA256 unchanged; user later authorised three comparison models. No projector/draft acquired |
| Physical context65536,one slot | Preserved in optimisation | Short matched4096 cross-model cohort is explicitly separate |
| F16 K/V,compactSWA | Preserved | v2 logs1920+250MiB KV,564.88MiB compute exactly match live CLI |
| MMAP,no_host,no repack | Preserved baseline | Full repack rejected by conservative backing+RSS policy; do not hide it behind incremental cgroup figures |
| Actual CPUworker placement | Measured | Original4P/mask0x55; selected8P-SMT/mask0xff. Prefill16/mask0xffff unchanged; per-trial affinity receipts |
| Reasoning,sampler,seed,termination | Preserved original coding cohort | temp1/topP.95/topK64/minP0/seed42; no generation deadline/output/reasoning cap,no shifts/repairs/retries |
| Existing compiled runtime/libraries | Preserved | New external replay harness only; original live executable/libraries unchanged, hashes retained |
| Old Clang/libomp GemmaE4B release | Retest,not transplanted | Existing native binary kept fixed to isolate configuration effects; different architecture,quant and MTP workload |
| Old Q4_N4 CPU scheduling | Excluded as inapplicable | This model's relevant weights are MXFP4/Q5/Q6/Q8,not historical denseQ4_0 E4B |
| MTP/draft | Excluded | No matching assistant supplied/downloaded; old E4B assistant cannot be assumed compatible |
| Hybrid ownership/handoff | Retest | New Gemma4MoE model,large backing and64k capacity require own proof,not inherited E4B qualification |
| Old disabled services | Excluded from restoration | Only the preserved ThinkingCap service is resumed after trials |
| Web UI defaults | Preserved pending source work | Seven tested uncommitted root edits remain; no active binary replaced solely for build-default policy |

## Opportunity ledger

| Opportunity | Status | Next decision / limitation |
|---|---|---|
| CPUdecode4/6/8/12/16 andSMT/physical placement | Confirmed | Eight P-core SMT workers won; ABBA/BAAB4observations/arm show about4.5% decode gain with identical full-logit hashes. Original uncapped coding cohort remains4P |
| Relax decode affinity | Screened | Slower in two observations; no promotion |
| CPUFA-on | Screened | Slightly slower decode;640MiB less globalKV. Potential memory frontier,not unconditional speed win |
| UB128 ->256 | Screened | Did not beat selected8P-SMT/ub128; no promotion |
| UB512 /FAoff | Preflight rejection | Conservative bound21785539904bytes exceeds20GiB; no native timing or quality claim |
| GPU-prefill with CPUexperts/sharedKV | Rejected under20GiB protocol | Short trial stopped by startup telemetry admission before timing;64k preflight bound23071322552bytes exceeded20GiB. New available-RAM budget not tested; no lifecycle/speed qualification |
| GPUexpert caches | Conditional | Need admitted useful parent and available budget; do not copy Flint's4GiB setting onto this64k deployment |
| PartialCPU expert repacking | Research,not implemented | Existing per-tensor buffer overrides andCPU_REPACK extras may pack a bounded subset. ExtraBUFT discovery is available via backend registry. Preserve quantisation; do not weaken handoff admission. Need whole-model timing and task checks before promotion |
| Release original mmap regions after synchronousCPU repack | Research,not implemented | Existing llama_model_loader::unmap_weight helper is used by quantisation but not current load. Could remove redundant raw mappings while retaining packed representation; requires ownership/alias/check_tensors async-validation audit and synthetic+trained tests. Any accounting must cover ALL remaining mapped backing plus ALL packed/private data,not only resident raw pages. No guard weakening based on cgroup alone |
| PersistentCPU packed-weight cache | Deferred | First establish repacking whole-model gain; avoid a new cache format without evidence |
| Additional model comparison | Active | User approved baseGemma4MXFP4_MOE,Qwen3.6UD-Q4_K_XL,NemotronQ4_0. All three pinned files checksum-verified. Serial comparisons freeze23.25GiB from available RAM minus2GiB; original20GiB results kept separate |

Rejected v1 full-SWA setups remain under `trials/`; they are invalid inheritance,not comparative performance points. Accepted/rejected v2 trials and exact configuration records are under `compact-v2/`. No exhaustive optimum or populated64k capacity claim is supported by short replay.
