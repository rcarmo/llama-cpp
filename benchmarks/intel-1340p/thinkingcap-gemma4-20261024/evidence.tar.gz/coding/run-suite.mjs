import fs from 'node:fs';import {execFileSync} from 'node:child_process';import {cases}from './cases.mjs';
const root=import.meta.dir,base=root.replace(/\/coding$/,''),endpoint='http://192.168.1.70:11434',status=root+'/status.txt';
if(fs.existsSync(status))throw Error('Series already started; inspect persisted state, do not duplicate');
const verifyFrozen=()=>execFileSync('sha256sum',['-c','FROZEN-SHA256SUMS'],{cwd:root,stdio:'pipe'});
const writeStatus=s=>fs.writeFileSync(status,new Date().toISOString()+' '+s+'\n');
const score=(...args)=>execFileSync('bash',[root+'/score-container.sh',...args],{encoding:'utf8'});
verifyFrozen();writeStatus('references');fs.writeFileSync(root+'/references.jsonl',score('references'));
fs.writeFileSync(root+'/results.jsonl','');fs.writeFileSync(root+'/protocol.json',JSON.stringify({source_cases:'Flint coding-unlimited, byte-identical cases/verify/case JSON',model:'ThinkingCap-Gemma4',transport:'OpenAI-compatible local HTTP SSE',context:65536,output_cap:null,reasoning_cap:null,temperature:1,top_p:0.95,top_k:64,min_p:0,seed:42,cache_prompt:false,no_repairs_or_retries:true,finite_logits_checked:false,stop_mapping:'Only finish_reason=stop plus SSE[DONE] maps to eog for unchanged scorer; native EOG token is not directly instrumented',comparison:'Flint used native harness/greedy sampling and publication pauses; no matched speedup or post-training/base quality claim'},null,2)+'\n');
try{
for(const task of cases){
  verifyFrozen();const c=JSON.parse(fs.readFileSync(root+'/'+task.id+'.case.json','utf8'));if(c.prompt!==task.prompt)throw Error('Frozen prompt mismatch');
  const model=await fetch(endpoint+'/v1/models',{timeout:false}).then(r=>r.json());if(!model.data?.some(x=>x.id==='ThinkingCap-Gemma4'))throw Error('Unexpected model; aborting series');
  // Admit each case only when the one slot is idle; no concurrent native jobs.
  while(true){const slots=await fetch(endpoint+'/slots',{timeout:false}).then(r=>r.json());if(!slots.some(x=>x.is_processing))break;writeStatus('waiting for idle slot before '+task.id);await Bun.sleep(1000);}
  writeStatus('generating '+task.id+'; no generation deadline or output cap');
  const request={messages:[{role:'user',content:task.prompt}],stream:true,stream_options:{include_usage:true},sse_ping_interval:1,return_progress:true,cache_prompt:false,reasoning_control:true,reasoning_format:'deepseek',chat_template_kwargs:{enable_thinking:true},temperature:1.0,top_p:0.95,top_k:64,min_p:0,seed:42};
  fs.writeFileSync(root+'/'+task.id+'.request.json',JSON.stringify(request,null,2)+'\n');
  const start=performance.now(),rawFd=fs.openSync(root+'/'+task.id+'.stream.txt','wx');let content='',reasoning='',finish=null,timings=null,usage=null,done=false,error=null;
  try{
    const response=await fetch(endpoint+'/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request),timeout:false});if(!response.ok)throw Error('HTTP'+response.status+' '+await response.text());
    let pending='';const decoder=new TextDecoder();
    const line=l=>{if(!l.startsWith('data: '))return;const data=l.slice(6).trim();if(data==='[DONE]'){done=true;return;}const e=JSON.parse(data);if(e.error)throw Error(JSON.stringify(e.error));const choice=e.choices?.[0];content+=choice?.delta?.content??'';reasoning+=choice?.delta?.reasoning_content??'';if(choice?.finish_reason)finish=choice.finish_reason;if(e.timings)timings=e.timings;if(e.usage)usage=e.usage;};
    for await(const chunk of response.body){fs.writeSync(rawFd,chunk);pending+=decoder.decode(chunk,{stream:true});let i;while((i=pending.indexOf('\n'))>=0){line(pending.slice(0,i).replace(/\r$/,''));pending=pending.slice(i+1);}fs.writeFileSync(root+'/'+task.id+'.progress.json',JSON.stringify({at:new Date().toISOString(),id:task.id,elapsed_ms:performance.now()-start,answer_chars:content.length,reasoning_chars:reasoning.length,timings})+'\n');}
    pending+=decoder.decode();if(pending.trim())line(pending);
  }catch(e){error=String(e.message??e);}finally{fs.closeSync(rawFd);}
  const output={id:task.id,content,reasoning,generated:usage?.completion_tokens??timings?.predicted_n??null,prompt:usage?.prompt_tokens??timings?.prompt_n??null,pp_ms:timings?.prompt_ms??null,tg_ms:timings?.predicted_ms??null,wall_ms:performance.now()-start,finite:null,native_logits_checked:false,stop:!error&&done&&finish==='stop'?'eog':error?'api_error':finish??'incomplete',stop_source:'api_finish_reason',api_finish_reason:finish,sse_done:done,timings,usage,error};
  const file=root+'/'+task.id+'.output.json';fs.writeFileSync(file,JSON.stringify(output,null,2)+'\n');
  const scored=JSON.parse(score('score',task.id,file));fs.writeFileSync(root+'/'+task.id+'.score.json',JSON.stringify(scored,null,2)+'\n');fs.appendFileSync(root+'/results.jsonl',JSON.stringify(scored)+'\n');verifyFrozen();
  if(error){writeStatus('native/API failure '+task.id+'; not retried');throw Error(error);}
}
const rows=fs.readFileSync(root+'/results.jsonl','utf8').trim().split('\n').map(JSON.parse);writeStatus('complete '+rows.filter(x=>x.pass).length+'/'+rows.length+' passed');
}catch(e){writeStatus('STOPPED: '+e.message);throw e;}
