#!/usr/bin/env bash
# Guarded ThinkingCap text-model run; no boot enablement or unrelated restoration.
set -euo pipefail
umask 077
ws=/var/home/agent/workspace
run="$ws/tmp/llama-cpp/runs/thinkingcap-gemma4-20261024/cpu64k-faoff-p8-norepack"
bin="$ws/tmp/llama-cpp/build/source-1309921403/flint-vulkan/bin"
model="$ws/projects/models/thinkingcap-gemma-4-26b/ThinkingCap-gemma-4-26B-A4B-it-MXFP4_MOE.gguf"
model_bytes=$(stat -c %s "$model")
ui="$ws/tmp/llama-cpp/cache/webui/db5de8f7d19a10b055b5527343d83e6fb23c9d1488ee7286f078b88668f55130"
export TMPDIR="$run/tmp" TMP="$run/tmp" TEMP="$run/tmp" BUN_TMPDIR="$run/tmp"
name=thinkingcap-gemma4-p8-webui
if podman container exists "$name";then echo 'Container exists; inspect persisted state instead of duplicating it.' >&2;exit 1;fi
available=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo)
(( available >= 2097152 )) || { echo 'Host reserve unavailable';exit 1; }
limit=$(( (available*1024-2147483648)/67108864*67108864 ))
(( limit > model_bytes+3221225472 )) || { echo "Insufficient available-RAM admission bound";exit 1; }
printf "%s\n" "$limit" > "$run/budget-bytes.txt"
stop() { podman stop --time 15 "$name" >/dev/null 2>&1 || true; }
trap 'printf "supervisor interrupted\n" > "$run/guard-stop.txt";stop;exit 0' TERM INT
podman run --detach --name "$name" --restart=no \
  --cpus=16 --memory="$limit" --memory-swap="$limit" --pids-limit=256 \
  --userns=keep-id --security-opt label=disable --cap-drop=all \
  --publish 192.168.1.70:11434:8080 \
  --volume "$bin:$bin:ro" --volume "$model:$model:ro" \
  --volume "$ui:$ui:ro" --volume "$run/tmp:$run/tmp:rw" \
  --env TMPDIR="$run/tmp" --env TMP="$run/tmp" --env TEMP="$run/tmp" \
  --env XDG_CACHE_HOME="$run/tmp/cache" \
  --log-driver=k8s-file --log-opt path="$run/server.log" --log-opt max-size=10mb \
  --entrypoint "$bin/llama-server" localhost/llama-intel-build:fedora44 \
  --verbosity 4 --model "$model" --alias ThinkingCap-Gemma4 --device none --gpu-layers 0 \
  --load-mode mmap --no-host --no-repack --no-op-offload --no-kv-offload \
  --threads 8 --threads-batch 16 --cpu-mask 0xff --cpu-mask-batch 0xffff \
  --cpu-strict 1 --cpu-strict-batch 1 --poll 50 --poll-batch 50 \
  --ctx-size 65536 --parallel 1 --batch-size 512 --ubatch-size 128 \
  --flash-attn off --cache-type-k f16 --cache-type-v f16 \
  --cache-ram 0 --ctx-checkpoints 0 --no-context-shift \
  --n-predict -1 --reasoning on --reasoning-format deepseek --reasoning-budget -1 \
  --chat-template-kwargs '{"enable_thinking":true}' \
  --temp 1.0 --top-p 0.95 --top-k 64 --min-p 0 --seed 42 \
  --host 0.0.0.0 --port 8080 --threads-http 4 --path "$ui" > "$run/container.id"
podman inspect "$name" > "$run/container-inspect-start.json"
pid=$(podman inspect --format '{{.State.Pid}}' "$name")
cgroup=$(awk -F: '$1=="0" {print $3}' "/proc/$pid/cgroup")
printf 'utc,host_available_kib,process_swap_kib,cgroup_bytes,cgroup_swap_bytes,estimated_total_bytes\n' > "$run/resource-monitor.csv"
printf 'running; guarded; LAN only; no boot enablement\n' > "$run/status.txt"
while [[ $(podman inspect --format '{{.State.Running}}' "$name" 2>/dev/null) == true ]];do
  available=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo)
  swap=$(awk '/VmSwap:/ {print $2}' "/proc/$pid/status" 2>/dev/null || true)
  memory=$(cat "/sys/fs/cgroup$cgroup/memory.current" 2>/dev/null || echo unknown)
  cgswap=$(cat "/sys/fs/cgroup$cgroup/memory.swap.current" 2>/dev/null || echo unknown)
  read -r process_rss model_rss < <(awk -v model="$model" '/^[0-9a-f]+-[0-9a-f]+ / {in_model=index($0,model)>0} /^Rss:/ {total+=$2;if(in_model)mapped+=$2} END {print total+0,mapped+0}' "/proc/$pid/smaps" 2>/dev/null) || { stop;break; }
  estimated_total=$((model_bytes + (process_rss-model_rss)*1024))
  printf '%s,%s,%s,%s,%s,%s\n' "$(date -u +%FT%TZ)" "$available" "${swap:-unknown}" "$memory" "$cgswap" "$estimated_total" >> "$run/resource-monitor.csv"
  if [[ -z "$swap" || "$memory" == unknown || "$cgswap" == unknown ]] || (( available < 2097152 || swap > 0 || cgswap > 0 || estimated_total > limit ));then
    printf 'resource guard: available_kib=%s swap_kib=%s cgroup_swap=%s estimated_total_bytes=%s\n' "$available" "${swap:-unknown}" "$cgswap" "$estimated_total" > "$run/guard-stop.txt"
    stop
    break
  fi
  sleep 5
done
printf 'stopped at %s\n' "$(date -u +%FT%TZ)" > "$run/status.txt"
podman inspect "$name" > "$run/container-inspect-stop.json"
