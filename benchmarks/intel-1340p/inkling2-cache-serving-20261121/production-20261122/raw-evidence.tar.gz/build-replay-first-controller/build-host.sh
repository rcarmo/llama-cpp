#!/bin/bash
set -euo pipefail
ws=/var/home/agent/workspace
run="$ws/tmp/llama-cpp/runs/inkling-prod-20261122-c0dad48a5"
runtime="$ws/tmp/llama-cpp/runs/upstream-review-20261114-976edc030/private-podman.sh"
stage=${1:?};[[ "$stage" =~ ^(build)$ ]]
name="inkling-prod-$stage-20261122"
export TMPDIR="$run/tmp" TMP="$run/tmp" TEMP="$run/tmp" BUN_TMPDIR="$run/tmp"
p(){ bash "$runtime" "$@"; }
watchdog=0;owned=0
finish(){
 rc=$?;trap - EXIT TERM INT HUP
 if ((watchdog));then kill "$watchdog" 2>/dev/null || true;wait "$watchdog" 2>/dev/null || true;fi
 if ((owned));then p stop --time 20 "$name" > "$run/$stage.stop.log" 2>&1 || true;fi
 echo "$rc" > "$run/$stage.host.exit";exit "$rc"
}
trap finish EXIT;trap 'exit 143' TERM INT HUP
test ! -e "$run/$stage.host.exit"
for spec in 'memory.max 4294967296' 'memory.swap.max 0' 'cpu.max 200000 100000';do cg=$(awk -F: '$1==0{print $3}' /proc/self/cgroup);test "$(cat /sys/fs/cgroup$cg/${spec%% *})" = "${spec#* }";done
curl -fsS --max-time 5 http://192.168.1.70:11434/slots |jq -e 'all(.[];.is_processing==false)' >/dev/null
production_pid=$(p top inkling2-mini-cache768-webui-20261121 hpid comm |awk '$2=="llama-server"{print $1;exit}')
test -n "$production_pid"
! p container exists "$name"
owned=1
p run -d --name "$name" --network none --cpus 2 --memory 4g --memory-swap 4g --pids-limit 512 --userns keep-id --security-opt label=disable --cap-drop=all -v "$ws:$ws" -w "$ws/projects/llama-cpp" --entrypoint /bin/bash localhost/llama-intel-build:fedora44 "$run/build-inner.sh" "$stage" > "$run/$stage.container.id"
pid=$(p inspect "$name" --format '{{.State.Pid}}');owned_cg=$(awk -F: '$1==0{print $3}' /proc/"$pid"/cgroup)
controller_pid=$$
(
 trap - EXIT
 while [[ $(p inspect "$name" --format '{{.State.Running}}') = true ]];do
  reason=''
  if ! curl -fsS --max-time 5 http://192.168.1.70:11434/slots |jq -e 'all(.[];.is_processing==false)' >/dev/null;then reason=production_busy;fi
  available=$(awk '/MemAvailable:/{print $2}' /proc/meminfo);((available>=2097152)) || reason=host_reserve
  while read -r np nc;do
   [[ "$np" = "$production_pid" ]] && continue
   pcg=$(awk -F: '$1==0{print $3}' /proc/"$np"/cgroup 2>/dev/null || true)
   [[ -z "$pcg" || "$pcg" = "$owned_cg" || "$pcg" = "$owned_cg/"* || "$pcg" = "$cg" || "$pcg" = "$cg/"* ]] || reason="native_contention:$np:$nc"
  done < <(ps -eo pid=,comm= |awk '$2~/^(llama-server|replay-audited|llama-bench|llama-cli|whisper-cli|diar-server|cc1plus|cc1|clang[-+0-9]*|gcc|g\+\+|glslc|ninja|cmake)$/')
  if [[ -n "$reason" ]];then echo "$reason" > "$run/$stage.guard-stop.txt";kill -TERM "$controller_pid";exit;fi
  sleep 2
 done
) & watchdog=$!
p wait "$name" > "$run/$stage.container-exit"
p logs "$name" > "$run/$stage.build.log" 2>&1
p inspect "$name" --format '{{.State.Status}} {{.State.ExitCode}} {{.Id}}' > "$run/$stage.container-state.txt"
test "$(cat "$run/$stage.container-exit")" = 0
test ! -e "$run/$stage.guard-stop.txt"
