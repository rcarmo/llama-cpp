#!/bin/bash
set -euo pipefail
ws=/var/home/agent/workspace
run="$ws/tmp/llama-cpp/runs/inkling-prod-20261122-c0dad48a5"
prior="$ws/tmp/llama-cpp/runs/inkling-optimize-20261121-5ac2abf2b"
trap 'rc=$?;printf "%s\n" "$rc" > "$run/build.inner.exit"' EXIT
cd "$ws/projects/llama-cpp"
export WORKSPACE_ROOT="$ws" LLAMA_SOURCE_DIR="$prior/source" BUILD_VARIANT=inkling-opt-cpu JOBS=2
source scripts/agent-paths.sh
llama_agent_init_paths
llama_agent_prepare_paths
for spec in 'memory.max 4294967296' 'memory.swap.max 0' 'cpu.max 200000 100000';do test "$(cat "/sys/fs/cgroup/${spec%% *}")" = "${spec#* }";done
for k in memory.max memory.swap.max cpu.max;do echo "$k $(cat /sys/fs/cgroup/$k)";done
head=$(cat "$run/source-head.txt")
test "$(git -C "$LLAMA_SOURCE_DIR" rev-parse HEAD)" = "$head"
test -z "$(git -C "$LLAMA_SOURCE_DIR" status --porcelain)"
make agent-paths > "$run/build-paths.log"
make agent-build
for spec in 'LLAMA_BUILD_SERVER:BOOL=ON' 'LLAMA_BUILD_UI:BOOL=ON' 'LLAMA_USE_PREBUILT_UI:BOOL=ON' 'GGML_VULKAN:BOOL=OFF';do grep -Fx "$spec" "$LLAMA_BUILD_DIR/CMakeCache.txt";done
export PYTHONPATH="$ws/tmp/llama-cpp/cache/python/jinja-3.1.6-markupsafe-3.0.2/modules${PYTHONPATH:+:$PYTHONPATH}"
export TEST_ARG_HARDWARE_CONCURRENCY=2 TEST_ARG_PARALLEL_WORKERS=1
mkdir -p "$run/fresh-models"
bash scripts/agent-build.sh exec "$LLAMA_BUILD_DIR/bin/test-llama-archs" -o "$run/fresh-models" > "$run/fresh-models.log" 2>&1
bash scripts/agent-build.sh exec "$LLAMA_BUILD_DIR/bin/test-llama-context" --models "$run/fresh-models" > "$run/fresh-context.log" 2>&1
make agent-test "TEST_ARGS=--parallel 1 --timeout 180 --output-on-failure --output-junit $run/cpu-ctest.xml -E '(test-download-model|test-llama-context|test-thread-safety|test-arg-parser|test-eval-callback|test-conversion|test-kv-cache-scales|test-backend-ops-semantic-replay)'" > "$run/cpu-ctest.log" 2>&1
base=$(cat "$ws/tmp/llama-cpp/runs/inkling-cache-serving-20261121-1dadee62b/runtime-path.txt")
closure="$run/qualified-cpu-closure"
test ! -e "$closure";mkdir "$closure"
cp -a "$LLAMA_BUILD_DIR/bin/"lib*.so* "$LLAMA_BUILD_DIR/bin/llama-server" "$closure/"
cp -p "$base/replay-audited" "$closure/"
c++ -O3 -std=c++17 -I"$LLAMA_SOURCE_DIR/ggml/include" -I"$LLAMA_SOURCE_DIR/ggml/src" "$prior/check-simd-dot.cpp" -ldl -o "$run/check-simd-dot"
LD_LIBRARY_PATH="$closure" taskset -c 0 "$run/check-simd-dot" "$base/libggml-cpu.so" "$closure/libggml-cpu.so" > "$run/simd-exact-dot.log"
objdump -d --disassemble=ggml_vec_dot_iq4_nl_q8_0 "$closure/libggml-cpu.so" > "$run/simd.disassembly.txt"
grep -q vpdpbusd "$run/simd.disassembly.txt"
LD_LIBRARY_PATH="$closure" "$closure/llama-server" --version > "$run/server-version.txt" 2>&1
hash=$(sha256sum "$closure/llama-server" |cut -c1-12)
published="$ws/projects/llama-cpp/runtime/deployments/inkling2-mini-cpu-${head:0:9}-$hash"
test ! -e "$published";cp -a "$closure" "$published"
sha256sum "$published/"* > "$run/runtime.sha256"
printf '%s\n' "$published" > "$run/runtime-path.txt"
test "$(git -C "$LLAMA_SOURCE_DIR" rev-parse HEAD)" = "$head"
test -z "$(git -C "$LLAMA_SOURCE_DIR" status --porcelain)"
echo 'PASS clean pinned CPU production build, embedded UI, fresh context fixtures, offline CTests, exact SIMD and versioned runtime closure'
