#!/bin/bash
set -euo pipefail
ws=/var/home/agent/workspace
run="$ws/tmp/llama-cpp/runs/inkling-prod-20261122-c0dad48a5"
runtime="$ws/tmp/llama-cpp/runs/upstream-review-20261114-976edc030/private-podman.sh"
p(){ bash "$runtime" "$@"; }
label=${1:?}; config=${2:?}
[[ "$label" =~ ^[a-z0-9-]+$ && "$config" =~ ^[a-z0-9-]+$ ]]
export TMPDIR="$run/tmp/native-$label" TMP="$run/tmp/native-$label" TEMP="$run/tmp/native-$label" BUN_TMPDIR="$run/tmp/native-$label"
mkdir -p "$TMPDIR"
test ! -e "$run/$label.exit";test ! -e "$run/$label.container.id"
file="$run/native-configs/$config.json"
test -f "$file"
variant=$(jq -r .closure "$file");[[ "$variant" = cpu || "$variant" = vulkan ]]
closure=$(cat "$run/qualified-$variant-path.txt")
test "$variant" = cpu
sha256sum -c "$run/runtime.sha256" > "$run/$label.closure-verified.txt"
model=$(jq -r .model "$file");projector=$(jq -r .projector "$file")
test -f "$closure/replay-audited"
cp -p "$file" "$run/$label.config.json"
available=$(awk '/MemAvailable:/{print $2}' /proc/meminfo)
(( available*1024 >= 24964497408+2147483648 ))
for live in inkling2-mini-cache768-webui-20261121 inkling2-mini-webui-20261120 gemma4-base-webui-20261114;do
 test "$(p inspect "$live" --format '{{.State.Running}}')" = false
done
if p container exists inkling2-mini-simd-webui-20261121;then
 test "$(p inspect inkling2-mini-simd-webui-20261121 --format '{{.State.Running}}')" = false
fi
# Limit values must exist on the delegated unit, not just in Podman arguments.
cg=$(awk -F: '$1==0{print $3}' /proc/self/cgroup)
for spec in 'memory.max 24964497408' 'memory.swap.max 0' 'cpu.max 1600000 100000';do
 key=${spec%% *};value=${spec#* };test "$(cat "/sys/fs/cgroup$cg/$key")" = "$value"
done
name="inkling-prod-$label-20261122"
cleanup(){
 rc=$?;trap - EXIT
 if p container exists "$name";then
  p stop --time 15 "$name" >/dev/null 2>&1 || true
  p inspect "$name" > "$run/$label.container-after.json" || true
 fi
 exit "$rc"
}
trap cleanup EXIT
trap 'exit 143' TERM INT HUP
envs=()
while IFS= read -r kv;do
 key=${kv%%=*}
 [[ "$key" =~ ^(FLINT_|MOE_|GGML_CPU_|GGML_VK_|GGML_OP_OFFLOAD_|GGML_SCHED_|OMP_NUM_THREADS) ]]
 envs+=(--env "$kv")
done < <(jq -r '.env|to_entries[]|"\(.key)=\(.value)"' "$file")
devices=();gpu=0
if [[ "$variant" = vulkan ]];then
 test "$(cat "$run/counter-test.exit")" = 0
 devices=(--device /dev/dri/renderD128 --group-add keep-groups);gpu=1
fi
cache="$ws/tmp/llama-cpp/cache/inkling-opt-native"
mkdir -p "$cache/xdg" "$cache/mesa"
p run -d --name "$name" --network none --cpus 16 --memory 24964497408 --memory-swap 24964497408 \
 --pids-limit 512 --userns keep-id --security-opt label=disable --cap-drop=all "${devices[@]}" \
 -v "$ws:$ws" -w "$run" -e TMPDIR="$TMPDIR" -e TMP="$TMPDIR" -e TEMP="$TMPDIR" \
 -e LD_LIBRARY_PATH="$closure" -e XDG_CACHE_HOME="$cache/xdg" \
 -e MESA_SHADER_CACHE_DIR="$cache/mesa" -e GGML_VK_VISIBLE_DEVICES=0 -e GGML_SCHED_PREFETCH_EXPERTS=0 \
 -e MOE_DUMP_LOGITS="$run/$label.logits.f32" "${envs[@]}" --entrypoint /bin/bash localhost/llama-intel-build:fedora44 \
 "$run/native-entry.sh" "$label" "$model" "$projector" "$closure/replay-audited" "$gpu" > "$run/$label.container.id"
pid=$(p inspect "$name" --format '{{.State.Pid}}')
cg=$(awk -F: '$1==0{print $3}' /proc/"$pid"/cgroup)
{ echo "container_pid=$pid";echo "cgroup=$cg";for k in memory.max memory.swap.max cpu.max;do printf '%s ' "$k";cat "/sys/fs/cgroup$cg/$k";done; } > "$run/$label.kernel-start.txt"
test "$(cat "/sys/fs/cgroup$cg/memory.max")" = 24964497408
test "$(cat "/sys/fs/cgroup$cg/memory.swap.max")" = 0
test "$(cat "/sys/fs/cgroup$cg/cpu.max")" = '1600000 100000'
for ((i=0;i<120;i++));do
 if ! grep -q BENCH_CONFIG "$run/$label.native.log" 2>/dev/null;then
  test "$(p inspect "$name" --format '{{.State.Running}}')" = true || break
  sleep 1;continue
 fi
 native=$(p top "$name" hpid comm |awk '$2~/^replay-audited/{print $1;exit}')
 if [[ -n "$native" ]];then
  for f in /proc/"$native"/task/*/status;do awk '/^Name:|^Cpus_allowed_list:/{printf "%s ",$0}END{print ""}' "$f";done > "$run/$label.affinity-start.txt"
  awk '/lib(llama|ggml)/{print $NF}' /proc/"$native"/maps |sort -u > "$run/$label.libraries.txt"
  for f in /proc/"$native"/fdinfo/*;do grep -q '^drm-' "$f" 2>/dev/null && { echo "===${f##*/}";cat "$f"; } || true;done > "$run/$label.gpu-fdinfo-start.txt"
  break
 fi
 sleep 1
done
timeout --signal=TERM --kill-after=20 900 /bin/bash "$runtime" wait "$name" > "$run/$label.container-exit"
test "$(cat "$run/$label.exit")" = 0
test ! -f "$run/$label.guard-stop.txt"
grep -E 'TOKEN_STREAM_HASH|BENCH_CONFIG|BENCH_RESULT|LOGITS_HASH|RESULT ' "$run/$label.native.log"
