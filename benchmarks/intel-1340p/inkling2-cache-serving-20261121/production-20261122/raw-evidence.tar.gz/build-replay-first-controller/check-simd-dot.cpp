#define GGML_COMMON_DECL_CPP
#include "ggml-common.h"
#include "ggml-cpu.h"
#include <dlfcn.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static uint32_t rng = 42;
static uint32_t random_u32() { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng; }
static ggml_vec_dot_t load_dot(const char * path) {
    void * lib = dlopen(path, RTLD_NOW | RTLD_LOCAL | RTLD_DEEPBIND);
    if (!lib) { std::fprintf(stderr, "%s\n", dlerror()); std::exit(1); }
    auto init = reinterpret_cast<void (*)()>(dlsym(lib, "ggml_cpu_init"));
    const auto fn = reinterpret_cast<ggml_vec_dot_t>(dlsym(lib, "ggml_vec_dot_iq4_nl_q8_0"));
    if (!init || !fn) std::exit(2);
    init();
    Dl_info info = {};
    if (!dladdr(reinterpret_cast<void *>(fn), &info)) std::exit(2);
    std::printf("DOT_LIBRARY path=%s symbol=%s\n", info.dli_fname, info.dli_sname);
    return fn;
}
int main(int argc, char ** argv) {
    if (argc != 3) return 2;
    const auto base = load_dot(argv[1]);
    const auto cand = load_dot(argv[2]);
    size_t count = 0, nonzero = 0;
    const uint16_t scales[] = {0, 1, 0x2000, 0x3800, 0x3c00, 0x4000, 0xbc00, 0x7bff};
    for (int n : {32, 64, 96, 128, 288, 1152, 2304, 4608, 8192}) {
        std::vector<block_iq4_nl> x(n/32);
        std::vector<block_q8_0> y(n/32);
        for (int trial = 0; trial < 512; ++trial) {
            for (size_t b = 0; b < x.size(); ++b) {
                x[b].d = scales[random_u32()%8]; y[b].d = scales[random_u32()%8];
                for (int j = 0; j < 16; ++j) x[b].qs[j] = uint8_t(random_u32());
                for (int j = 0; j < 32; ++j) y[b].qs[j] = int8_t(int(random_u32()%255)-127);
                if (trial < 16) {
                    std::memset(x[b].qs, trial | (trial << 4), sizeof(x[b].qs));
                    std::memset(y[b].qs, trial%2 ? 127 : -127, sizeof(y[b].qs));
                }
            }
            float a, c;
            base(n, &a, 0, x.data(), 0, y.data(), 0, 1);
            cand(n, &c, 0, x.data(), 0, y.data(), 0, 1);
            if (!std::isfinite(a) || !std::isfinite(c) || std::memcmp(&a, &c, sizeof(a))) {
                std::fprintf(stderr,"FAIL n=%d trial=%d baseline=%a candidate=%a\n",n,trial,a,c); return 1;
            }
            ++count;
            nonzero += a != 0;
        }
        // Model-sized hot-cache dot timing, ABBA then BAAB, same input and call boundary.
        volatile float sink = 0;
        for (int round = 0; round < 8; ++round) {
            const bool candidate = round == 1 || round == 2 || round == 4 || round == 7;
            auto fn = candidate ? cand : base;
            const int reps = 2000000/n*32;
            const auto start = std::chrono::steady_clock::now();
            for (int k = 0; k < reps; ++k) { float out; fn(n,&out,0,x.data(),0,y.data(),0,1); sink = out; }
            const double ns = std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-start).count()/reps;
            std::printf("DOT_BENCH n=%d round=%d variant=%s ns=%.3f sink=%a\n",n,round,candidate?"candidate":"baseline",ns,float(sink));
        }
    }
    if (nonzero < 1000) { std::fprintf(stderr,"FAIL uninitialised or degenerate oracle nonzero=%zu\n",nonzero); return 1; }
    std::printf("PASS exact IQ4_NL dot comparisons=%zu nonzero=%zu seed=42 validQ8range=-127:127\n",count,nonzero);
}
