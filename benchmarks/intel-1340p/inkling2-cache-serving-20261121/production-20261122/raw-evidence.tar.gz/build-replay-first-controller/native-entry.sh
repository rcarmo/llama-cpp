#!/bin/bash
set -euo pipefail
run=/var/home/agent/workspace/tmp/llama-cpp/runs/inkling-prod-20261122-c0dad48a5
label=$1; model=$2; projector=$3; binary=$4; gpu=$5
test "$(cat /sys/fs/cgroup/memory.max)" = 24964497408
test "$(cat /sys/fs/cgroup/memory.swap.max)" = 0
test "$(cat /sys/fs/cgroup/cpu.max)" = '1600000 100000'
test "$MOE_CONTEXT" = 65536
exec /bin/bash "$run/native-guard.sh" "$run" "$label" "$model" "$projector" 24964497408 "$gpu" "$binary" "$model" > "$run/$label.native.log" 2>&1
