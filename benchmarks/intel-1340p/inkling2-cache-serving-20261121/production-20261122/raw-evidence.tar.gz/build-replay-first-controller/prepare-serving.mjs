import fs from 'node:fs';
const ws='/var/home/agent/workspace',root=ws+'/tmp/llama-cpp/runs/';
const run=root+'inkling-prod-20261122-c0dad48a5',parent=root+'inkling-cache-serving-20261121-1dadee62b',campaign=root+'inkling-optimize-20261121-5ac2abf2b';
const oldName='inkling2-mini-cache768-webui-20261121',name='inkling2-mini-prod-webui-20261122';
function write(name,text){if(fs.existsSync(run+'/'+name))throw Error('Refuse overwrite: '+name);fs.writeFileSync(run+'/'+name,text);}
for(const file of ['launch.sh','entry.sh','guard.sh','unit-start.sh','verify-service.sh','check-api.mjs','check-serving-cache.mjs','check-vision.mjs','check-browser.mjs','verify-ready.mjs','verify-profile.mjs']){
  let text=fs.readFileSync(parent+'/'+file,'utf8').replaceAll(parent,run).replaceAll('inkling-cache-serving-20261121-1dadee62b','inkling-prod-20261122-c0dad48a5').replaceAll(oldName,name).replaceAll('serve-cache768','serve-prod');
  if(['unit-start.sh','verify-service.sh'].includes(file))text=text.replace('test "$(p inspect inkling2-mini-simd-webui-20261121',`test "$(p inspect ${oldName} --format '{{.State.Running}}')" = false\ntest "$(p inspect inkling2-mini-simd-webui-20261121`);
  if(file==='verify-profile.mjs')text=text.replace("if(parent)expected[expected.indexOf('--cache-ram')+1]='256';\n",'').replace('capacity_mib:parent?256:768', 'capacity_mib:768').replace("only_production_factor_changed:'--cache-ram 256 -> 768'",'arguments_unchanged:true');
  write(file,text);
}
for(const file of ['vision-fixture.png','vision-fixture-swapped.png'])fs.copyFileSync(parent+'/'+file,run+'/'+file,fs.constants.COPYFILE_EXCL);
fs.copyFileSync(parent+'/original.index.html',run+'/original.index.html',fs.constants.COPYFILE_EXCL);
write('native-entry.sh',fs.readFileSync(campaign+'/native-entry.sh','utf8').replaceAll(campaign,run));
write('native-guard.sh',fs.readFileSync(campaign+'/native-guard.sh','utf8'));
let trial=fs.readFileSync(campaign+'/native-trial.sh','utf8').replaceAll(campaign,run).replaceAll('inkling-optimize-20261121-5ac2abf2b','inkling-prod-20261122-c0dad48a5');
const begin=trial.indexOf('override=$(jq'),end=trial.indexOf('model=$(jq');
if(begin<0||end<=begin)throw Error('Native override block changed');
trial=trial.slice(0,begin)+'test "$variant" = cpu\nsha256sum -c "$run/runtime.sha256" > "$run/$label.closure-verified.txt"\n'+trial.slice(end);
trial=trial.replace('for live in inkling2-mini-webui-20261120',`for live in ${oldName} inkling2-mini-webui-20261120`).replace('name="inkling-opt-$label"','name="inkling-prod-$label-20261122"').replace('  p rm "$name" >/dev/null || true\n','');
write('native-trial.sh',trial);
const config=JSON.parse(fs.readFileSync(campaign+'/native-configs/simd512-unpack4.json'));
delete config.closure_path;delete config.simd_variant;config.name='candidate';
fs.mkdirSync(run+'/native-configs');write('native-configs/candidate.json',JSON.stringify(config,null,2)+'\n');
const baseline=campaign+'/t512-b1';
const accepted=JSON.parse(fs.readFileSync(baseline+'.config.json'));
if(JSON.stringify(accepted.env)!==JSON.stringify(config.env))throw Error('Baseline native configuration mismatch');
write('native-baseline.json',JSON.stringify({source:'1dadee62b291391d7b6c230fa81f04a2358c6bf2',config:baseline+'.config.json',logits:baseline+'.logits.f32',log:baseline+'.native.log',purpose:'One new-runtime qualification, not a repeated performance campaign'},null,2)+'\n');
console.log('Prepared inherited cache768 CPU serving and exact retained-baseline replay controls');
