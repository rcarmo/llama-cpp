#!/bin/bash
set -euo pipefail
ws=/var/home/agent/workspace
run="$ws/tmp/llama-cpp/runs/inkling-prod-20261122-c0dad48a5"
runtime="$ws/tmp/llama-cpp/runs/upstream-review-20261114-976edc030/private-podman.sh"
name=inkling-prod-candidate-replay-20261122
p(){ bash "$runtime" "$@"; }
export TMPDIR="$run/tmp" TMP="$run/tmp" TEMP="$run/tmp" BUN_TMPDIR="$run/tmp"
child=0;watchdog=0
finish(){
 rc=$?;trap - EXIT TERM INT HUP
 if ((watchdog));then kill "$watchdog" 2>/dev/null || true;wait "$watchdog" 2>/dev/null || true;fi
 if ((rc!=0));then
  if p container exists "$name";then p stop --time 20 "$name" > "$run/native-stop.log" 2>&1 || true;fi
  if ((child));then kill -TERM "$child" 2>/dev/null || true;wait "$child" 2>/dev/null || true;fi
 fi
 echo "$rc" > "$run/native-host.exit";exit "$rc"
}
trap finish EXIT;trap 'exit 143' TERM INT HUP
test ! -e "$run/native-host.exit"
cg=$(awk -F: '$1==0{print $3}' /proc/self/cgroup)
for spec in 'memory.max 24964497408' 'memory.swap.max 0' 'cpu.max 1600000 100000';do test "$(cat "/sys/fs/cgroup$cg/${spec%% *}")" = "${spec#* }";done
controller_pid=$$
(
 trap - EXIT
 while true;do
  reason='';available=$(awk '/MemAvailable:/{print $2}' /proc/meminfo)
  ((available>=2097152)) || reason=host_reserve
  while read -r np nc;do
   pcg=$(awk -F: '$1==0{print $3}' /proc/"$np"/cgroup 2>/dev/null || true)
   [[ -z "$pcg" || "$pcg" = "$cg" || "$pcg" = "$cg/"* ]] || reason="native_contention:$np:$nc"
  done < <(ps -eo pid=,comm= |awk '$2~/^(llama-server|replay-audited|llama-bench|llama-cli|whisper-cli|diar-server|cc1plus|cc1|clang[-+0-9]*|gcc|g\+\+|glslc|ninja|cmake)$/')
  if [[ -n "$reason" ]];then echo "$reason" > "$run/native.guard-stop.txt";kill -TERM "$controller_pid";exit;fi
  sleep 2
 done
) & watchdog=$!
bash "$run/native-trial.sh" candidate-replay candidate > "$run/native-trial.log" 2>&1 & child=$!
wait "$child"
test ! -e "$run/native.guard-stop.txt"
