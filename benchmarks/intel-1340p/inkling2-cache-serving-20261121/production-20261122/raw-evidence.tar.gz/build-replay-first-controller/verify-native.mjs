import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const run='/var/home/agent/workspace/tmp/llama-cpp/runs/inkling-prod-20261122-c0dad48a5',baseline=JSON.parse(fs.readFileSync(run+'/native-baseline.json'));
const candidate=fs.readFileSync(run+'/candidate-replay.logits.f32'),old=fs.readFileSync(baseline.logits);
assert.deepEqual(candidate,old,'CPU full-vocabulary logits changed');
assert.equal(candidate.length%4,0);let n=0;
for(let i=0;i<candidate.length;i+=4){assert.ok(Number.isFinite(candidate.readFloatLE(i)),'Non-finite logit at '+i/4);n++;}
assert.ok(n>0);
const closure=fs.readFileSync(run+'/runtime-path.txt','utf8').trim(),libraries=fs.readFileSync(run+'/candidate-replay.libraries.txt','utf8').trim().split('\n');
assert.ok(libraries.length>0);for(const path of libraries)assert.ok(path.startsWith(closure+'/'),'Wrong native library: '+path);
assert.equal(fs.readFileSync(run+'/candidate-replay.gpu-fdinfo-start.txt','utf8').trim(),'','Unexpected GPU client');
assert.equal(fs.readFileSync(run+'/candidate-replay.exit','utf8').trim(),'0');
const result={passed:true,purpose:'New production runtime regression qualification, not a throughput campaign',candidateSource:fs.readFileSync(run+'/source-head.txt','utf8').trim(),baselineSource:baseline.source,promptTokens:512,generationSteps:64,repetitions:2,finiteLogits:n,logitBytes:candidate.length,sha256:createHash('sha256').update(candidate).digest('hex'),bitIdenticalFullLogits:true,actualClosure:closure,cpuOnly:true,nativeMemoryMax:24964497408,nativeSwapMax:0,nativeCpuMax:'1600000 100000'};
fs.writeFileSync(run+'/native-qualified.json',JSON.stringify(result,null,2)+'\n');console.log('PASS '+n+' finite full-vocabulary logits, byte-identical to accepted SIMD4/16 baseline; exact closure, CPU only');
