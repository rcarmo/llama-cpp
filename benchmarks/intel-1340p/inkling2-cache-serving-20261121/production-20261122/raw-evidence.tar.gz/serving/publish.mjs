import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const ws='/var/home/agent/workspace',root=ws+'/tmp/llama-cpp/runs/',prior=root+'inkling-prod-20261122-c0dad48a5',run=root+'inkling-prod-serving-20261122-c0dad48a5',source=root+'inkling-optimize-20261121-5ac2abf2b/source';
assert.equal(fs.readFileSync(run+'/cutover.exit','utf8').trim(),'0');
const accepted=JSON.parse(fs.readFileSync(run+'/accepted.json')),native=JSON.parse(fs.readFileSync(run+'/native-qualified.json'));
const resources=[];
for(const dir of [prior,run])for(const name of fs.readdirSync(dir)){
 if(!/^(candidate-replay|serve-prod-\d).*\.monitor\.csv$/.test(name))continue;
 const rows=fs.readFileSync(dir+'/'+name,'utf8').trim().split('\n').slice(1).map(l=>l.split(',').map(Number));
 assert.ok(rows.length);
 for(const row of rows){assert.ok(row.every(Number.isFinite));assert.equal(row[2],0);assert.equal(row[4],0);assert.ok(row[1]>=2097152);assert.ok(row[3]<=24964497408);assert.ok(row[5]<=24964497408);assert.equal(row[8],0);assert.equal(row[10],0);}
 resources.push({run:dir,label:name,samples:rows.length,maxConservativeBytes:Math.max(...rows.map(x=>x[5])),maxCgroupBytes:Math.max(...rows.map(x=>x[3])),minHostAvailableKiB:Math.min(...rows.map(x=>x[1])),swapMax:0,gpuBytesMax:0});
}
assert.ok(resources.length>=3);
const resource={passed:true,ceilingBytes:24964497408,hostReserveBytes:2147483648,supervisionAllowanceBytes:268435456,maxConservativeBytes:Math.max(...resources.map(x=>x.maxConservativeBytes)),observations:resources};
fs.writeFileSync(run+'/resource-qualified.json',JSON.stringify(resource,null,2)+'\n',{flag:'wx'});
const staging=run+'/evidence-staging';fs.mkdirSync(staging);
for(const [directory,destination] of [[prior,'build-replay-first-controller'],[run,'serving']]){
 const out=staging+'/'+destination;fs.mkdirSync(out);
 for(const name of fs.readdirSync(directory)){
  if(!fs.statSync(directory+'/'+name).isFile()||name.startsWith('primary-')||name==='serve-prod.server.log'||name==='fetch.log'||name==='check-simd-dot')continue;
  if(!/\.(sh|mjs|json|txt|log|csv|xml|exit|id|sha256|f32|html|png)$/.test(name))continue;
  fs.copyFileSync(directory+'/'+name,out+'/'+name);
 }
 fs.mkdirSync(out+'/native-configs');fs.copyFileSync(directory+'/native-configs/candidate.json',out+'/native-configs/candidate.json');
}
const reference=root+'inkling-optimize-20261121-5ac2abf2b/t512-b1';
for(const [original,name] of [[reference+'.config.json','reference.config.json'],[reference+'.native.log','reference.native.log'],[root+'inkling-optimize-20261121-5ac2abf2b/check-simd-dot.cpp','check-simd-dot.cpp']])fs.copyFileSync(original,staging+'/build-replay-first-controller/'+name);
assert.deepEqual(fs.readFileSync(reference+'.logits.f32'),fs.readFileSync(prior+'/candidate-replay.logits.f32'));
fs.linkSync(staging+'/build-replay-first-controller/candidate-replay.logits.f32',staging+'/build-replay-first-controller/reference.logits.f32');
const hashes=[];function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,entry.name);if(entry.isDirectory())walk(file);else hashes.push(createHash('sha256').update(fs.readFileSync(file)).digest('hex')+'  '+path.relative(staging,file));}}walk(staging);
fs.writeFileSync(staging+'/MANIFEST.sha256',hashes.sort().join('\n')+'\n');
const rel='benchmarks/intel-1340p/inkling2-cache-serving-20261121/production-20261122',destination=source+'/'+rel;
assert.ok(!fs.existsSync(destination));fs.mkdirSync(destination,{recursive:true});
for(const name of ['accepted.json','serving-profile.json','native-qualified.json','resource-qualified.json','harness-audit.json','ownership-unit.log','final-unit.txt','before-restart.identity.txt','after-restart.identity.txt','runtime.sha256','api-verification.json','qualification-cache.revisit-reuse.json','vision-verification.json','browser-chat.json','browser-chat.png','cutover.exit'])fs.copyFileSync(run+'/'+name,destination+'/'+name);
const report=`# Inkling CPU production runtime, 22 November 2026

Inkling 2 Mini is live at http://192.168.1.70:11434/ from source \`${accepted.runtime_source_commit}\`. The CPU4/16/cache768 profile is unchanged. GPU serving is disabled.

- Accepted: ${accepted.accepted}.
- Runtime: \`${accepted.runtime}\`.
- Unit/container: \`inkling2-mini-prod-webui-20261122\`, transient, \`Restart=no\`.
- Model: official Inkling 2 Mini IQ4_NL; existing Q8_0 CPU vision projector. No downloads or model changes.
- Exact [arguments](serving-profile.json): strict4/16, masks0x55/0xffff, poll50, context65536/parallel1, batch512/ubatch128, F16 KV/FAoff, cache768MiB, checkpoints2/default spacing8192, mmap/no-host/no-repack, no operation/KV offload or context shift. High/deepseek reasoning and generation/reasoning remain uncapped.
- Previous CPU cache768/1dadee62b container is stopped and retained as the immediate rollback. SIMD/cache256, original Inkling and Gemma remain stopped. No boot/global-default changes or unrelated restoration.

## Qualification

| Check | Result |
|---|---|
| Clean pinned CPU build, embedded UI | PASS; actual4GiB/swap0/2CPU build limits |
| Offline CTests | 92/92 PASS; eight existing offline-filter patterns excluded; fresh context suite run separately |
| Fresh context fixtures | 142/142 models PASS; historical cached fixtures preserved |
| IQ4_NL SIMD | 4608 exact dot comparisons; VNNI disassembly retained |
| New-runtime trained CPU replay | ${native.finiteLogits} finite logits, ${native.logitBytes} bytes; byte-identical to accepted SIMD4/16 baseline |
| Native replay workload | 512 prompt,64 teacher-forced steps,two observations plus existing warmup; no performance claim |
| Actual native caps | 24964497408bytes,swap0,cpu.max1600000/100000 |
| Full backing/non-model RSS guard | Maximum ${resource.maxConservativeBytes}bytes, including256MiB supervision; host reserve >=2GiB; GPU bytes0 |
| API | add19+23/tool result42, prefix215, actual-delta cancellation, drain and natural-EOG READY |
| Long cache revisit | 2089 reused tokens/4 evaluated; uncapped READY |
| Embedded UI/browser | Original HTML bytes; real UI chat OK, separated reasoning,natural stop,no output cap |
| CPU vision | Red/blue counterbalanced images PASS |
| Recovery | Exact cache768 parent rollback PASS; same candidate container restarted with a different PID; final READY/native/profile checks PASS |

[Accepted receipt](accepted.json), [native comparison](native-qualified.json), [resources](resource-qualified.json), [browser capture](browser-chat.png), [raw evidence](raw-evidence.tar.gz).

Native crash respawn, a populated64K context and broad coding/visual quality were not tested. GPU quality/serving,CUDA and Metal remain unqualified. The earlier cache ABBA and GPU placement measurements were not repeated.

## First controller failure and reuse

The first controller exited143 because its contention check rejected the owned private-Podman sibling cgroup. The native replay completed with exit0 and all expected frames before exact parent recovery (exit0). Both controller outcomes and frozen scripts are retained. The serving-only retry reused that completed replay and the same immutable build. Its ownership check recognises only the exact parent/candidate container IDs, including siblings; eight positive/negative ownership tests and the final live controller pass. No valid replay arm was repeated.

## Prior-feature reuse checklist

- [x] Feature: wide-LUT IQ4_NL SIMD and strict4/16 pools.
  - Source: 1dadee62b and the accepted SIMD/cache768 profile.
  - Applicability: unchanged measured CPU winner.
  - Status: applied.
  - Implementation: new pinned CPU closure and inherited launch arguments.
  - Evidence: exact dot probes,full-vocabulary replay and exact argv checks.
- [x] Feature: embedded UI and workspace path/build wrappers.
  - Source: scripts/agent-build.sh,scripts/agent-paths.sh and the accepted serving harness.
  - Applicability: required build/UI/path defaults.
  - Status: applied.
  - Implementation: make agent-paths/build/test; UI/prebuilt ON,Vulkan OFF for this CPU build.
  - Evidence: build logs,original HTML comparison and live browser completion.
- [x] Feature: bounded cache768/checkpoints and uncapped API/vision.
  - Source: 6543c98c1; inkling-cache-serving-20261121-1dadee62b helpers.
  - Applicability: accepted serving profile.
  - Status: adapted.
  - Implementation: copied helpers in a fresh namespace; only runtime/container/receipt paths change.
  - Evidence: exact argv,2089-token revisit,tools,cancellation,images and browser checks.
- [x] Feature: full-backing/RSS reserve guard and retained-container rollback.
  - Source: accepted guard.sh,unit-start.sh,rollback.sh and cutover.sh.
  - Applicability: serial model ownership and exact recovery.
  - Status: adapted.
  - Implementation: unchanged memory guard; exact previous cache768 rollback; exact-ID sibling ownership check.
  - Evidence: resource CSVs,ownership8,explicit rollback and retained-child restart.
- [x] Feature: Vulkan expert placement/shared CPU views.
  - Source: f07f44b9e,fea919c6d and the retained GPU research reports.
  - Applicability: GPU paths are outside this CPU cutover; CPU_Mapped backing does not meet the Vulkan-owned CPU-view contract.
  - Status: not applicable.
  - Implementation: GPU remains disabled; fixes remain in source.
  - Evidence: CPU-only build/argv/zero DRM clients; prior scoped GPU tests remain separate from serving qualification.

## Recovery and evidence

For deliberate rollback, first wait for idle slots, stop \`inkling2-mini-prod-webui-20261122.service\`, then run \`${run}/rollback.sh\`. It restores the exact previous cache768 container/runtime, checks native caps,argv,HTML and READY. Do not rerun either one-shot cutover controller.

Raw build/replay/first-controller inputs: \`${prior}\`. Serving-only retry: \`${run}\`. The archive retains snapshots of both namespaces,exact reference/candidate logits,full test logs,frozen manifests and recovery evidence; it excludes executables,weights,build caches and the unrelated primary patch. Live guards continue after the snapshot. The owner fork's requested \`main\` is a fast-forward target; its default \`master\` is not renamed or changed by this publication.
`;
assert.ok(!/[^\x00-\x7f]/.test(report));fs.writeFileSync(destination+'/README.md',report);
const doc=source+'/docs/local/intel-i5-1340p/inkling2-cache-serving-20261121.md';let text=fs.readFileSync(doc,'utf8');
text=text.replace('Inkling 2 Mini serves at http://192.168.1.70:11434/ with the verified SIMD 1dadee62b runtime, 4/16 strict pools and 768 MiB bounded prompt cache. The accepted cache256 parent remains an immutable stopped rollback. Original Inkling and Gemma stay stopped. No push or boot changes.','Inkling 2 Mini serves at http://192.168.1.70:11434/ from the verified c0dad48a5 CPU runtime, with unchanged 4/16 strict pools and 768 MiB bounded prompt cache. The previous cache768/1dadee62b container is the stopped immediate rollback; cache256,original Inkling and Gemma also stay stopped. No boot/global-default changes. [22 November production qualification and recovery](../../../'+rel+'/README.md).');
text=text.replace('Only `--cache-ram 256 -> 768` changes.','The 21 November cache adoption changed only `--cache-ram 256 -> 768`.');
const start=text.indexOf('Current unit/container:'),end=text.indexOf('\n\nGPU diagnostics',start);assert.ok(start>=0&&end>start);
text=text.slice(0,start)+'Current unit/container: inkling2-mini-prod-webui-20261122 (transient,Restart=no). For deliberate rollback, wait for idle slots, stop that unit, then run rollback.sh from tmp/llama-cpp/runs/inkling-prod-serving-20261122-c0dad48a5. It restores the exact prior cache768/1dadee62b container and checks identity,limits,UI,argv and READY. Do not rerun one-shot cutover scripts. Native crash respawn and populated64K remain unqualified.'+text.slice(end);
text+='\n\n## CPU production rebuild, 22 November\n\nThe [new immutable CPU runtime](../../../'+rel+'/README.md) passed92 offline CTests,fresh context142/142,4608 exact SIMD probes and1,600,464 finite logits identical to the accepted baseline. Actual native caps,tools42/prefix215,long cache2089,cancel/recovery,embedded UI/browser,red/blue images,exact cache768 rollback and retained-child restart pass. CPU4/16/cache768/model/projector/reasoning/64K remain unchanged. The first controller sibling-ownership failure and exact recovery are retained; its completed native replay was reused. GPU serving remains disabled.\n';
fs.writeFileSync(doc,text);fs.writeFileSync(run+'/publication-path.txt',destination+'\n');
console.log('PASS validated resources; prepared scoped publication and frozen raw staging: '+destination);
