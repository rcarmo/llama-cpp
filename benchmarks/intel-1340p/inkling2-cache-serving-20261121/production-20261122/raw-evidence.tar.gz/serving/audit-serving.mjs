import fs from 'node:fs';
import assert from 'node:assert/strict';
const ws='/var/home/agent/workspace',root=ws+'/tmp/llama-cpp/runs/',run=root+'inkling-prod-serving-20261122-c0dad48a5',parent=root+'inkling-cache-serving-20261121-1dadee62b';
const profile=JSON.parse(fs.readFileSync(run+'/serving-profile.json')),accepted=JSON.parse(fs.readFileSync(run+'/parent-accepted.json'));
assert.deepEqual(profile.args,accepted.profile.args);
assert.equal(profile.binary_closure,fs.readFileSync(run+'/runtime-path.txt','utf8').trim());
assert.equal(profile.runtime_source_commit,fs.readFileSync(run+'/source-head.txt','utf8').trim());
for(const file of ['launch.sh','unit-start.sh','verify-service.sh','verify-parent.sh','rollback.sh','cutover.sh']){
 const text=fs.readFileSync(run+'/'+file,'utf8'),match=text.match(/^run=(?:"([^"\n]+)"|([^\n]+))$/m);
 assert.ok(match,'Missing run path: '+file);
 assert.equal((match[1]??match[2]).replace('$ws',ws),run,'Run escaped owned namespace: '+file);
}
for(const file of ['check-api.mjs','check-serving-cache.mjs','check-vision.mjs','check-browser.mjs','verify-ready.mjs','verify-profile.mjs']){
 const text=fs.readFileSync(run+'/'+file,'utf8');
 assert.ok(text.includes('inkling-prod-serving-20261122-c0dad48a5'),'Wrong script root: '+file);
 assert.ok(!text.includes('inkling-cache-serving-20261121-1dadee62b'),'Old output root: '+file);
}
assert.deepEqual(fs.readFileSync(run+'/guard.sh'),fs.readFileSync(parent+'/guard.sh'));
assert.deepEqual(fs.readFileSync(run+'/original.index.html'),fs.readFileSync(parent+'/original.index.html'));
for(const f of ['vision-fixture.png','vision-fixture-swapped.png'])assert.deepEqual(fs.readFileSync(run+'/'+f),fs.readFileSync(parent+'/'+f));
const launch=fs.readFileSync(run+'/launch.sh','utf8');
assert.ok(launch.includes('"$run/entry.sh" "$run"'),'Entry must receive the owned run path');
assert.ok(fs.readFileSync(run+'/entry.sh','utf8').includes('run=$1;model=$2;projector=$3;limit=$4;shift 4'),'Entry argument contract changed');
for(const s of ['--device none --gpu-layers 0','--cache-ram 768','--threads 4 --threads-batch 16','--ctx-size 65536 --parallel 1','--n-predict -1','--reasoning-budget -1','--no-mmproj-offload'])assert.ok(launch.includes(s),'Missing inherited setting: '+s);
assert.equal(JSON.parse(fs.readFileSync(run+'/native-configs/candidate.json')).closure,'cpu');
const result={passed:true,unchangedArguments:true,ownedOutputRoots:true,guardUnchanged:true,uiBytesUnchanged:true,visionFixturesUnchanged:true,cpuOnly:true};
fs.writeFileSync(run+'/harness-audit.json',JSON.stringify(result,null,2)+'\n');console.log('PASS inherited settings, new namespaces, unchanged UI/guard/vision fixtures and CPU-only controls');
