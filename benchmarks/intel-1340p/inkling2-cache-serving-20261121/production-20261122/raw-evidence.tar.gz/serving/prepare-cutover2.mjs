import fs from 'node:fs';
const root='/var/home/agent/workspace/tmp/llama-cpp/runs/',oldSlug='inkling-prod-20261122-c0dad48a5',newSlug='inkling-prod-serving-20261122-c0dad48a5',prior=root+oldSlug,run=root+newSlug;
const read=f=>fs.readFileSync(prior+'/'+f,'utf8'),write=(f,s)=>fs.writeFileSync(run+'/'+f,s,{flag:'wx'}),copy=f=>fs.copyFileSync(prior+'/'+f,run+'/'+f,fs.constants.COPYFILE_EXCL);
for(const f of ['launch.sh','entry.sh','guard.sh','unit-start.sh','verify-service.sh','verify-parent.sh','rollback.sh','check-api.mjs','check-serving-cache.mjs','check-vision.mjs','check-browser.mjs','verify-ready.mjs','verify-profile.mjs']){
 let text=read(f).replaceAll(oldSlug,newSlug);
 if(f==='launch.sh')text=text.replace('p run -d --name "$name"','p run -d --name "$name" --cidfile "$run/candidate-owned.id"');
 write(f,text);
}
for(const f of ['source-head.txt','runtime-path.txt','runtime.sha256','build-frozen.sha256','build.host.exit','build.inner.exit','parent-accepted.json','serving-profile.json','original.index.html','vision-fixture.png','vision-fixture-swapped.png'])copy(f);
fs.mkdirSync(run+'/native-configs');copy('native-configs/candidate.json');
let audit=read('audit-serving.mjs').replaceAll(oldSlug,newSlug).replace("'native-trial.sh','native-entry.sh','native-host.sh',",'');write('audit-serving.mjs',audit);
let native=read('verify-native.mjs').replace("const run='"+prior+"',baseline=", "const run='"+prior+"',output='"+run+"',baseline=").replace("run+'/native-qualified.json'","output+'/native-qualified.json'");
native=native.replace('const result={passed:true,',`assert.equal(fs.readFileSync(run+'/candidate-replay.container-exit','utf8').trim(),'0');\nassert.equal(fs.readFileSync(run+'/rollback.exit','utf8').trim(),'0');\nassert.equal(fs.readFileSync(run+'/native-host.exit','utf8').trim(),'143');\nassert.match(fs.readFileSync(run+'/native.guard-stop.txt','utf8').trim(),/^native_contention:\\d+:replay-audited$/);\nconst container=JSON.parse(fs.readFileSync(run+'/candidate-replay.container-after.json'))[0];\nassert.equal(container.Id,fs.readFileSync(run+'/candidate-replay.container.id','utf8').trim());\nassert.equal(container.State.ExitCode,0);\nconst kernel=fs.readFileSync(run+'/candidate-replay.kernel-start.txt','utf8');\nassert.ok(kernel.includes('/'+container.Id+'\\n'));\nassert.ok(kernel.includes('memory.max 24964497408\\n'));\nassert.ok(kernel.includes('memory.swap.max 0\\n'));\nassert.ok(kernel.includes('cpu.max 1600000 100000\\n'));\nconst result={passed:true,reusedCompletedReplay:true,attemptDirectory:run,firstControllerExit:143,firstFailure:'Controller rejected owned sibling cgroup; complete native replay exited0 before recovery',exactParentRestorationExit:0,`);
write('verify-retained-native.mjs',native);
let cutover=read('cutover.sh').replaceAll(oldSlug,newSlug);
const from=cutover.indexOf("echo 'PHASE native qualification"),to=cutover.indexOf("echo 'PHASE candidate server qualification'");
if(from<0||to<=from)throw Error('Cutover phase bounds changed');
cutover=cutover.slice(0,from)+'systemctl --user stop inkling2-mini-cache768-webui-20261121.service\nsleep 3\n'+cutover.slice(to);
cutover=cutover.replace('"$bun" "$run/audit-serving.mjs" > "$run/cutover-audit.log"','"$bun" "$run/audit-serving.mjs" > "$run/cutover-audit.log"\n"$bun" "$run/verify-retained-native.mjs" > "$run/native-qualification.log"');
cutover=cutover.replace('sha256sum -c "$run/baseline-frozen.sha256"','sha256sum -c "'+prior+'/baseline-frozen.sha256"');
cutover=cutover.replace('  systemctl --user stop "$native_unit.service" >/dev/null 2>&1 || true\n','').replace('  if p container exists inkling-prod-candidate-replay-20261122;then p stop --time 20 inkling-prod-candidate-replay-20261122 >/dev/null 2>&1 || true;fi\n','');
cutover=cutover.replace('sha256sum -c "$run/build-frozen.sha256" > "$run/cutover-build-integrity.log"','sha256sum -c "$run/build-frozen.sha256" > "$run/cutover-build-integrity.log"\nsha256sum -c "'+prior+'/serving-frozen.sha256" > "$run/first-attempt-harness-integrity.log"');
cutover=cutover.replace('maintenance=0','maintenance=0;watchdog=0').replace('rc=$?;trap - EXIT TERM INT HUP','rc=$?;trap - EXIT TERM INT HUP\n if ((watchdog));then kill "$watchdog" 2>/dev/null || true;wait "$watchdog" 2>/dev/null || true;fi');
cutover=cutover.replace("maintenance=1;date -u +%FT%TZ > \"$run/maintenance-started\"",`maintenance=1;date -u +%FT%TZ > "$run/maintenance-started"\nbash "$run/watch-ownership.sh" "$$" "$cg" & watchdog=$!`);
cutover=cutover.replace('sha256sum -c "$run/serving-frozen.sha256" > "$run/final-harness-integrity.log"','test ! -e "$run/ownership.guard-stop.txt"\nsha256sum -c "$run/serving-frozen.sha256" > "$run/final-harness-integrity.log"');
write('cutover.sh',cutover);
console.log('Prepared fresh serving-only cutover; retains completed build/replay and failed-controller recovery evidence');
