#!/bin/bash
set -euo pipefail
ws=/var/home/agent/workspace
run="$ws/tmp/llama-cpp/runs/inkling-prod-serving-20261122-c0dad48a5"
source="$ws/tmp/llama-cpp/runs/inkling-optimize-20261121-5ac2abf2b/source"
destination="$source/benchmarks/intel-1340p/inkling2-cache-serving-20261121/production-20261122"
bun=/opt/piclaw/current/bun/bin/bun
export TMPDIR="$run/tmp" TMP="$run/tmp" TEMP="$run/tmp" BUN_TMPDIR="$run/tmp"
export BUN_RUNTIME_TRANSPILER_CACHE_PATH="$ws/tmp/llama-cpp/cache/inkling-opt-native/bun-runtime"
trap 'rc=$?;echo "$rc" > "$run/publication.exit"' EXIT
test ! -e "$run/publication.exit"
cg=$(awk -F: '$1==0{print $3}' /proc/self/cgroup)
for spec in 'memory.max 4294967296' 'memory.swap.max 0' 'cpu.max 200000 100000';do test "$(cat "/sys/fs/cgroup$cg/${spec%% *}")" = "${spec#* }";done
test "$(cat "$run/cutover.exit")" = 0
sha256sum -c "$run/serving-frozen.sha256" > "$run/publication-harness-integrity.log"
sha256sum -c "$run/runtime.sha256" > "$run/publication-runtime-integrity.log"
bash "$run/watch-ownership.sh" --selftest > "$run/ownership-capped-test.log"
"$bun" "$run/publish.mjs"
(cd "$run/evidence-staging";sha256sum -c MANIFEST.sha256) > "$run/raw-staging-integrity.log"
tar --sort=name -C "$run/evidence-staging" -cf - . |gzip -n > "$destination/raw-evidence.tar.gz"
gzip -dc "$destination/raw-evidence.tar.gz" |tar -C "$run/evidence-staging" -df - > "$run/raw-archive-compare.log"
(cd "$destination";sha256sum raw-evidence.tar.gz > raw-evidence.sha256)
git -C "$source" diff --check
"$bun" -e 'const fs=require("node:fs"),path=require("node:path"),s="/var/home/agent/workspace/tmp/llama-cpp/runs/inkling-optimize-20261121-5ac2abf2b/source",files=[s+"/docs/local/intel-i5-1340p/inkling2-cache-serving-20261121.md",s+"/benchmarks/intel-1340p/inkling2-cache-serving-20261121/production-20261122/README.md"];let n=0;for(const f of files)for(const m of fs.readFileSync(f,"utf8").matchAll(/\]\(([^)]+)\)/g)){const u=m[1].split("#")[0];if(!u||/^[a-z]+:/.test(u))continue;if(!fs.existsSync(path.resolve(path.dirname(f),u)))throw Error("Broken link: "+f+" -> "+u);n++;}console.log("PASS "+n+" local report links");' > "$run/publication-links.log"
cat "$run/publication-links.log"
echo 'PASS scoped publication, raw snapshot hashes, archive comparison and report links; no model replay/build repeated'
