#!/bin/bash
set -euo pipefail
ws=/var/home/agent/workspace
run="$ws/tmp/llama-cpp/runs/inkling-prod-serving-20261122-c0dad48a5"
owned(){
 local process_cg=$1 controller_cg=$2 parent_id=$3 candidate_id=$4 app=${2%/*} id
 [[ "$process_cg" = "$controller_cg" || "$process_cg" = "$controller_cg/"* ]] && return 0
 for id in "$parent_id" "$candidate_id";do
  [[ "$id" =~ ^[0-9a-f]{64}$ ]] || continue
  [[ "$process_cg" = "$app/$id" || "$process_cg" = "$app/$id/"* ]] && return 0
 done
 return 1
}
if [[ ${1:-} = --selftest ]];then
 a=$(printf '%064d' 1);b=$(printf '%064d' 2);c=$(printf '%064d' 3);controller=/user/app/controller.service
 owned "$controller" "$controller" "$a" "$b"
 owned "$controller/child" "$controller" "$a" "$b"
 owned "/user/app/$a" "$controller" "$a" "$b"
 owned "/user/app/$b/child" "$controller" "$a" "$b"
 ! owned "/user/app/$c" "$controller" "$a" "$b"
 ! owned "/user/app/${b}x" "$controller" "$a" "$b"
 ! owned "${controller}-foreign" "$controller" "$a" "$b"
 ! owned /user/app/unidentified "$controller" "$a" ''
 echo 'PASS ownership8: controller, descendants and exact parent/candidate sibling IDs; reject foreign, near-ID and absent ownership'
 exit 0
fi
controller_pid=${1:?};controller_cg=${2:?}
parent_id=$(cat "$ws/tmp/llama-cpp/runs/inkling-cache-serving-20261121-1dadee62b/serve-cache768.container.id")
while kill -0 "$controller_pid" 2>/dev/null;do
 candidate_id='';[[ ! -f "$run/candidate-owned.id" ]] || candidate_id=$(cat "$run/candidate-owned.id")
 reason='';own_candidate=()
 available=$(awk '/MemAvailable:/{print $2}' /proc/meminfo);((available>=2097152)) || reason=host_reserve
 while read -r np nc;do
  pcg=$(awk -F: '$1==0{print $3}' /proc/"$np"/cgroup 2>/dev/null || true)
  [[ -n "$pcg" ]] || continue
  if ! owned "$pcg" "$controller_cg" "$parent_id" "$candidate_id";then reason="native_contention:$np:$nc:$pcg";fi
  if [[ "$candidate_id" =~ ^[0-9a-f]{64}$ && "$pcg" = "${controller_cg%/*}/$candidate_id" && "$nc" = llama-server ]];then own_candidate+=("$np");fi
 done < <(ps -eo pid=,comm= |awk '$2~/^(llama-server|replay-audited|llama-bench|llama-cli|whisper-cli|diar-server|cc1plus|cc1|clang[-+0-9]*|gcc|g\+\+|glslc|ninja|cmake)$/')
 if [[ -n "$reason" ]];then
  echo "$reason" > "$run/ownership.guard-stop.txt"
  for np in "${own_candidate[@]}";do kill -TERM "$np" 2>/dev/null || true;done
  kill -TERM "$controller_pid" 2>/dev/null || true
  exit 1
 fi
 sleep 2
done
