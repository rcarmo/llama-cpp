# Flint isolated trial, 23 October 2026

User authorises trying the best feasible Flint with existing zero-copy and effective expert cache/location management. No persistent service or old-model restoration. Worktree `implement/flint-zero-copy` from `be952865461273480faafcc98e2b6f526724bee3`; parent dirty policy files preserved separately. No agent coordination per user.

## Model selection

Official RecursiveSI/flint revision `2a247be0c0aec895ccb0ac7ca92229ec6df37288`: 39.8B total/2.5B active, 49 layers, 256 experts/layer with six routed plus shared expert; 35 SWA (513 window) and14 full-attention layers, no MTP. BF16 ~79.6GB, Q8~42.3GB, Q6>32GB, Q5~29.9GB, Q4>=23.4GB exceed the existing20GiB experiment memory cap before overhead. Chosen highest feasible listed precision is Unsloth UD-Q3_K_XL, revision `20468edfc38ab43d6914cc88b08cbecb05d0fc62`,18494977472 bytes/SHA256 `91b8d85ab6ff7fb095d9a972f9afa6f3fa2b9acb642867a079f3e013ea3c350c`. File verified, no quality equivalence claim. Lower IQ3/Q2 are not authorised to hide resource failures; retain the selected quantisation and20GiB cap.

## Resource/configuration inheritance

Use existing Fedora44 image, CPU/Vulkan native Release. Preserve20GiB cgroup cap, memory-swap=memory (zero container swap allowance), >=6GiB host reserve, isolated CPU4 workers, batch512/ubatch128, context2048 initial, F16KV/FAoff, mmap. No other active native inference/DRM client at preflight. Containers supervised with bounded timeouts and final drain. Peak/cap events, swap/OOM and host reserve monitored; no production changes. Do not auto-restore speech/Qwen/Gemma.

New runs use `tmp/llama-cpp/{build,cache,runs}` via parent Make wrappers selecting child source. Physical root `/var/home/agent/workspace`. Model completed deliverable in `projects/models/flint`; download partial stayed in run root.

## Prior-feature reuse checklist

- [x] Full/SWA atomic transfer, `src/llama-kv-cache-handoff.cpp` ISWA pair transfer: applied; both subcaches prepare before either commits. Existing `kv_cpu_shared` allocation and `llama_kv_handoff_cpu` general path used; strict Qwen-only flag is not widened. Synthetic paired-cache finite/logit and owner-lifetime test must pass before trained transfer.
- [x] Intel cached/coherent leased views, `ggml-vulkan-buffers.cpp`: applied unchanged; require positive shared bytes, copied0; destroy source owner before CPU continuation. No borrowed or copy-fallback acceptance. Final6/6 targeted CTests pass; final GPU cache16MiB synthetic compares600 exact all-vocab CPU continuation steps,final trained4GiB cache compares3 exact steps after205520896shared/0copied bytes and source-owner destruction.
- [x] CPU expert mmap plus separate dense/KV GPU placement: adapted following user correction "load experts, not layers". All routed expert tensors stay CPU-resident; dense tensors and KV use Vulkan for prefill. The existing layer-count API is fixed at all layers only to select dense/KV placement, never swept or used to choose expert residency. Explicit MMAP plus no_host confirmed actual CPU_Mapped backing and avoided prior pinned/duplicated allocation failures. Report actual tensor/buffer placement; the handoff exception admits only Flint's exact canonical CPU-expert override and still rejects arbitrary overrides.
- [x] Upstream SLRU dynamic expert cache, `src/llama-moe-cache.*`: reuse in a fixed-budget arm. Cache256MiB initially; inspect actual slot counts by compatible tensor-layout group, selected-expert hits/misses and uploaded bytes. Groups share slots across layers, so whole-model expert working-set percentages alone cannot predict cache effectiveness. Exercised0/128/256/512/1024/2048/4096MiB budgets, finite repeat-hash timing fixtures and final trained4096MiB source-owner-destruction handoff. Large prefill bypasses dynamic updates; cached experts can be copied back through the scheduler.4GiB hit60.20% but decode3.01tok/s loses to uncached GPU5.29 and CPU12.4-13.1. Static route-profile cache is deferred until representative profiling and a measured benefit justify it.
- [x] Scheduler staging/async CPU: deferred initial comparison; instrumentation and API present but overlapping staging would confound cache placement and memory. Keep defaults off; cache callback retained.
- [x] Native Jinja/PEG sampling: applied for semantic prompts; official recommended temperature1/top_p.95/top_k20 and explicit min_p0/seed42, bounded reasoning/output. Fixed-token/logit comparison separate from natural quality.
- [x] MTP: not applicable; official Flint has no NextN assistant advertised. No Gemma/Qwen trained weights reused.
- [x] Prior controlled handoff harnesses: adapted for Flint source geometry/accounting, same-state copied reference and source-owner destruction, plus CPU baseline and warm append; no frozen Nemotron quality rerun.

## Prespecified sequence

1. Build small fixture/harness in isolated worktree. Synthetic Flint CPU-copy transfer, invalidation/atomic failure and Vulkan view tests; no trained weights until these pass.
2. Exact Q3 CPU load/completion screen, retain full source/model/binary identity and memory cap evidence. Stop on OOM/reserve failure; do not raise limits.
3. Compare CPU-only, dense/KV GPU-prefill with CPU-routed experts and CPU zero-copy continuation, and the same with a256MiB selected-expert GPU cache. Do not sweep layers. Exercise identical bounded GPU append tokens for cache-disabled/enabled arms and record them separately from cold prefill. Record actual expert bank slots/hits/misses/upload bytes, loading, prefill, handoff, decode, whole-request cost and CPU append, buffers per backend and expert bytes. Require finite all-vocab values and exact same-state CPU reference after handoff; backend greedy equality is diagnostic only.
4. Cache residency retained only if task-correct measured workload and resource behaviour justify it. Bounded screen then at most ABBA confirmation for plausible finalist. Initial short reasoning/tool/code tasks must be independently checked; no general quality/deployment promotion.

Final result: ABBA confirms CPU16prompt/4P-coredecode,ubatch512,FAoff/F16KV at50.430prefill/13.085decode tok/s versus39.211/12.560 baseline; inferencewall-17.12%.1024prompt check also improves. Larger1/2/4GiB GPU caches pass bounded residency and final4GiB exact handoff but lose throughput. Final6/6 CTests pass. All trial jobs drained; no services deployed or restored. Native384-token chat ends mid-answer, so semantic completion/quality is not qualified. Report: workspace/reports/flint-throughput-20261023/README.md.

Known limits: one host/quant, small bounded context/tasks; no BF16 comparison, long262k context, GPU recovery or serving readiness. Store every failed attempt and corrected supplements separately.

## Throughput tuning extension

User now requests maximum tok/s. Other model-serving units and deployed ELF runtimes were removed with data/source/weights retained. No old service restoration or agent coordination. The first trained mmap/no-host zero-copy run passed with 205520896 shared bytes, zero copied bytes and exact same-state CPU logits for 3 steps; source owner destroyed. Synthetic GPU/cache runs compared 600 exact continuation steps; cache guard repair removes a null static-pack pointer dereference. AUTO mmap was disabled by Vulkan device capabilities, so explicit MMAP plus no_host is mandatory. Retain both prior OOM and resource-guard failures.

Reuse standard llama-bench threadpool API (`tools/llama-bench/llama-bench.cpp`), current test/context setup, CPU SIMD repacking, full/SWA zero-copy, SLRU selected-expert cache and phase counters. No layer-count sweep; routed backing stays on CPU. MTP remains not applicable. Static expert packs are deferred because no representative route profile exists; quant/KV precision stays unchanged. Scheduler async CPU is screened separately only if cache throughput warrants it. Existing Gemma-specific quant kernels are not transplanted onto Flint's mixed Q3/Q4/Q5 layout.

Screen controlled token replay: 512 real code/text prompt tokens, 64 fixed continuation tokens, finite all-vocab logits at each decode, two repetitions after a warm-up. Separate prefill and decode timing. Sweep CPU 2/3/4 threads and one attached-pool control, GPU cache 0/128/256/512 MiB (budgets not residency guarantees), ubatch64/128/256 and FA only as a separate factor. Initial memory-risk gate is trained256MiB handoff. Use fixed tokens for timing so output-dependent expert routes do not confound the screen; confirm finalists on the same fixture with counterbalanced independent runs, then a bounded real greedy completion and handoff validation. Long-prompt 1024-token confirmation if safe. Report individual repeats/medians, actual slots, hits/misses/uploads, memory events, reserve/swap, temperatures and GPU drain. Scope is best measured configuration, not proof of a global optimum or model quality/deployment qualification.

### CPU allowance extension

User explicitly authorises increasing cores. Cancelled the waiting four-core affinity/batch screen without interrupting native work. After the existing GPU512 trial drains, run matched CPU4 control then CPU6/8/12/16 with `--cpus=N`, both inference thread counts N, OMP_NUM_THREADS=N, no affinity mask, same build/fixture/FAoff/F16/ubatch128, 512 prompt +64 continuation, two reps each. Host has 12 physical cores (4 P plus 8 E) and16 logical CPUs;16 means hardware threads, not16 physical cores. Retain20GiB cap, zero swap and6GiB reserve,300-second timeout and serial ownership. Capture actual cgroup CPU quota/statistics as well as memory. Confirm top setting against control using counterbalanced independent runs.

### Larger selected-expert caches

User requests larger GPU caches:1024/2048/4096MiB. Extend only the test harness cache input bound, not runtime memory limits. After CPU scaling completes, build and retain binary hashes, then run the same512/64 fixture/two repeats at4 CPU threads with ubatch128/FAoff/F16KV. Record proportional layout group slots, actual cache bytes including spare slots, cumulative per-phase hit/miss/upload statistics, copied-hit traffic and20GiB resource receipts. These banks contain selected experts; original routed tensors stay CPU mmap-backed. No GPU layer-count sweep or model reload restoration. Stop larger budgets on any OOM, host reserve or swap failure. Compare with retained0/128/256/512MiB observations; follow up only on a plausible throughput winner. Native Vulkan cache may change numerical reductions: finite and within-configuration repeat hashes are required; changed cross-configuration logits alone are not a quality qualification. Keep source-owner destruction and exact same-state CPU handoff tests separate.

### Finalist screen

CPU scaling completed with verified matching cgroup quotas and no quota throttling.16 threads lead prefill (~41.67tok/s),4 threads lead decode (~12.4tok/s). Add separate batch-thread configuration to the isolated harness and screen16 batch/4 decode at ubatch64/128/256/512 with16CPU allowance. Test taskset P-core physical lanes0,2,4,6 and E-core lanes8-11 at4 threads separately, with affinity inherited by native workers; the earlier Podman cpuset attempt failed before execution because its controller is unavailable. P/E affinity has no core-count restriction beyond the physical lane mask. Rebuild only after native cache trials finish, retain binary hashes; compare replay hashes within equivalent attention layout. No runtime/kernel changes beyond the already identified guard/handoff changes. Confirm a finalist versus4/4 control counterbalanced, and retain one longer1024-token result if safe.

 Historical four-thread tests used OMP_NUM_THREADS=4; both are4 for the new control.


