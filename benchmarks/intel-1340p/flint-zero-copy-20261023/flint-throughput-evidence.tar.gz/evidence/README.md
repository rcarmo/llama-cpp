# Flint throughput and zero-copy, 23 October 2026

Best measured Sigma configuration: CPU16 prompt threads,4 P-core decode workers, microbatch512, F16KV/FAoff, explicit mmap/no_host. Counterbalanced512/64 replay confirms50.430 prompt and13.085 decode tok/s; baseline39.211/12.560. GPU caches1/2/4GiB improve hit rates but lose throughput;4GiB reaches60.20% hits and3.013 decode tok/s.

[Plan and prior-feature reuse checklist](plan.md). Retained report, individual JSON/CSV and evidence archive are under workspace `reports/flint-throughput-20261023/`. Source worktree remains isolated, uncommitted and unpushed. No deployment or global quality qualification. Final6/6 targeted CTests, synthetic600 exact continuation steps and trained4GiB cache handoff with205520896shared/0copied bytes pass. All trial containers/GPU clients drained. The bounded384-token native chat did not finish its answer.
